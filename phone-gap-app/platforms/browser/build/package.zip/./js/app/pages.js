var pages = {
    main: function(){
        
    }
};